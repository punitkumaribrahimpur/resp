package com.example.punitkumar.homework;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements DatePickerDialog.OnDateSetListener,TimePickerDialog.OnTimeSetListener{
    Button btn,submit;
    TextView result;
    int day,month,year,hour,min;
    int dayfinal,monthfinal,yearfinal,hourfinal,minfinal;
    EditText name1,mail1,mobile1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name1=(EditText)findViewById(R.id.name);
        mail1=(EditText) findViewById(R.id.mail);
        mobile1=(EditText)findViewById(R.id.mobile);
        submit=(Button)findViewById(R.id.sumbit);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Toast.makeText(MainActivity.this,"Successfull Saved",Toast.LENGTH_LONG).show();
                Intent i=new Intent(MainActivity.this,Login.class);
                startActivity(i);
            }
        });

        result=(TextView)findViewById(R.id.text);
        btn=(Button)findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar c=Calendar.getInstance();
                year=c.get(Calendar.YEAR);
                month=c.get(Calendar.MONTH);
                day=c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog=new DatePickerDialog(MainActivity.this,MainActivity.this,year,month,day);
                datePickerDialog.show();


            }
        });

    }

    public void onDateSet(DatePicker datePicker,int i,int i2,int i3)
    {
        yearfinal=i;
        monthfinal=i2+1;
        dayfinal=i3;

            Calendar c=Calendar.getInstance();
            hour=c.get(Calendar.HOUR_OF_DAY);
            min=c.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog=new TimePickerDialog(MainActivity.this,MainActivity.this,hour,min, android.text.format.DateFormat.is24HourFormat(this));
            timePickerDialog.show();

    }
    public void onTimeSet(TimePicker timePicker, int i, int i2)
    {
        hourfinal=i;
        minfinal=i2;
        result.setText(dayfinal+"/"+monthfinal+"/"+yearfinal+"Time:"+hourfinal+":"+minfinal);
    }


}
